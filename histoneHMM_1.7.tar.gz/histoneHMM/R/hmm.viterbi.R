hmm.viterbi <-
function(x, logmean, logsd, A, p_i) {return(path)}

